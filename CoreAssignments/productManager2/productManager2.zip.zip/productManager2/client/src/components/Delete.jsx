import React from 'react';

const Delete = (props) => {
    return (
        <div>Delete</div>
    );
};

export default Delete;