import { useState, useEffect } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';

const FindAll = (props) => {

    const [productList, setProductList] = useState([]);
    const [loaded, setLoaded] = useState(false);

    useEffect(() => {
        axios.get("http://localhost:8000/api/products")
            .then(res => {
                console.log(res.data);
                setProductList(res.data);
                setLoaded(true);
            })
            .catch(err => console.log(err));
    }, []);

    const deleteMe = (Id) => {
        axios.delete(`http://localhost:8000/api/products/${Id}`)
            .then(res => {
                console.log(res.data);
                const filteredProduct = productList.filter((eachProduct) => {
                    return eachProduct._id !== Id;
                });
                setProductList(filteredProduct);
            })
            .catch(err => console.log(err));
    };

    return (
        <div>
            {
                productList.map(oneProductList => {
                    return (
                        <div key={oneProductList._id}>
                            <Link to={'/products/' + oneProductList._id}>
                                <h3>{oneProductList.title}</h3>
                            </Link>
                            <h2>{oneProductList.price}</h2>
                            <h2>{oneProductList.description}</h2>
                            <button onClick={() => deleteMe(oneProductList._id)}>Deleter</button>
                            <br />
                            <Link to={'/products/' + oneProductList._id + '/update'}>Edit</Link>
                            <hr />
                        </div>
                    );
                })
            }
        </div>
    );
};

export default FindAll;